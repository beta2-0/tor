/*
  # Create offers and deals tables

  1. New Tables
    - `offers`
      - For storing cryptocurrency sell offers
      - Includes price, amount, payment method, and wallet details
      - RLS enabled with policies for public reading and authenticated user management
    
    - `deals`
      - For tracking transactions between buyers and sellers
      - Links to offers and users
      - Includes status tracking (pending, paid, completed)
      - RLS enabled with role-specific policies
  
  2. Security
    - RLS enabled on both tables
    - Policies for:
      - Public offer viewing
      - Authenticated user offer management
      - Deal creation and status updates
      - Deal visibility for involved parties
  
  3. Additional Features
    - Automatic timestamps
    - Status validation
    - Updated_at trigger for deals
*/

-- Create offers table
CREATE TABLE IF NOT EXISTS offers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  coin text NOT NULL,
  country text NOT NULL,
  price numeric NOT NULL,
  payment_method text NOT NULL,
  wallet_address text NOT NULL,
  amount numeric NOT NULL,
  type text NOT NULL DEFAULT 'sell',
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'completed', 'cancelled')),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on offers
ALTER TABLE offers ENABLE ROW LEVEL SECURITY;

-- Create offers policies
CREATE POLICY "Anyone can read active offers"
  ON offers
  FOR SELECT
  TO public
  USING (status = 'active');

CREATE POLICY "Users can create their own offers"
  ON offers
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own offers"
  ON offers
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create deals table
CREATE TABLE IF NOT EXISTS deals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  offer_id uuid REFERENCES offers(id) NOT NULL,
  buyer_id uuid REFERENCES auth.users(id) NOT NULL,
  seller_id uuid REFERENCES auth.users(id) NOT NULL,
  status text NOT NULL CHECK (status IN ('pending', 'paid', 'completed')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS on deals
ALTER TABLE deals ENABLE ROW LEVEL SECURITY;

-- Create deals policies
CREATE POLICY "Users can read their own deals as buyer or seller"
  ON deals
  FOR SELECT
  TO authenticated
  USING (
    auth.uid() = buyer_id OR 
    auth.uid() = seller_id
  );

CREATE POLICY "Buyers can create deals"
  ON deals
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = buyer_id);

CREATE POLICY "Buyers can update status to paid"
  ON deals
  FOR UPDATE
  TO authenticated
  USING (
    auth.uid() = buyer_id AND 
    status = 'pending'
  );

CREATE POLICY "Sellers can update status to completed"
  ON deals
  FOR UPDATE
  TO authenticated
  USING (
    auth.uid() = seller_id AND 
    status = 'paid'
  );

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_deals_updated_at
  BEFORE UPDATE
  ON deals
  FOR EACH ROW
  EXECUTE PROCEDURE update_updated_at_column();