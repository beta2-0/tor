/*
  # Initial Schema Setup

  1. Tables
    - offers: Store sell offers
    - profiles: User profiles with wallet info
  
  2. Security
    - RLS enabled on all tables
    - Policies for authenticated access
*/

-- Create offers table
CREATE TABLE IF NOT EXISTS offers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  coin text NOT NULL,
  country text NOT NULL,
  price numeric NOT NULL,
  amount numeric NOT NULL,
  payment_method text NOT NULL,
  wallet_address text NOT NULL,
  type text DEFAULT 'sell' CHECK (type = 'sell'),
  status text DEFAULT 'active' CHECK (status IN ('active', 'completed', 'cancelled')),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE offers ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DO $$ 
BEGIN
    DROP POLICY IF EXISTS "Anyone can read active offers" ON offers;
    DROP POLICY IF EXISTS "Users can create their own offers" ON offers;
    DROP POLICY IF EXISTS "Users can update their own offers" ON offers;
EXCEPTION
    WHEN undefined_object THEN 
        NULL;
END $$;

-- Create policies
CREATE POLICY "Anyone can read active offers"
  ON offers
  FOR SELECT
  TO public
  USING (status = 'active');

CREATE POLICY "Users can create their own offers"
  ON offers
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own offers"
  ON offers
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id),
  mobile text UNIQUE NOT NULL,
  wallets jsonb DEFAULT '{}'::jsonb,
  role text DEFAULT 'user'::text,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DO $$ 
BEGIN
    DROP POLICY IF EXISTS "Users can view own profile" ON profiles;
    DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
EXCEPTION
    WHEN undefined_object THEN 
        NULL;
END $$;

-- Create policies
CREATE POLICY "Users can view own profile"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Create function to handle new user creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (id, mobile, wallets)
  VALUES (
    NEW.id,
    NEW.raw_user_meta_data->>'mobile',
    '{}'::jsonb
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- Create trigger for new user creation
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();