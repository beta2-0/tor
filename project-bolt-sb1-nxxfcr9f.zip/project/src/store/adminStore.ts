import { create } from 'zustand';
import { AdminStats, User, Offer } from '../types';
import { getMockUsers, updateMockUserStatus } from './authStore';
import { useOfferStore } from './offerStore';

interface AdminState {
  stats: AdminStats;
  users: User[];
  offers: Offer[];
  isLoading: boolean;
  error: string | null;
  selectedTimeRange: '24h' | '7d' | '30d' | 'all';
}

interface AdminActions {
  fetchStats: () => Promise<void>;
  fetchUsers: () => Promise<void>;
  fetchOffers: () => Promise<void>;
  updateUserStatus: (userId: string, status: User['status']) => Promise<void>;
  updateOfferStatus: (offerId: string, status: Offer['status']) => Promise<void>;
  setTimeRange: (range: AdminState['selectedTimeRange']) => void;
}

type AdminStore = AdminState & AdminActions;

// Generate mock transaction data for the given number of days
const generateMockTransactions = (days: number) => {
  const transactions = [];
  const now = new Date();
  
  for (let i = days; i >= 0; i--) {
    const date = new Date(now);
    date.setDate(date.getDate() - i);
    
    transactions.push({
      date: date.toISOString().split('T')[0],
      volume: Math.floor(Math.random() * 500000) + 300000 // Random volume between 300k and 800k
    });
  }
  
  return transactions;
};

// Mock data
const mockStats: AdminStats = {
  totalUsers: 1000,
  activeUsers: 750,
  totalOffers: 2500,
  activeOffers: 1200,
  totalVolume: 15000000,
  recentTransactions: generateMockTransactions(30),
  userGrowth: {
    daily: 25,
    weekly: 150,
    monthly: 600
  },
  offerMetrics: {
    completionRate: 85,
    averageAmount: 2500,
    popularCoins: ['BTC', 'ETH', 'USDT'],
    popularCountries: ['India', 'USA', 'Nigeria']
  },
  systemHealth: {
    uptime: 99.9,
    responseTime: 250,
    errorRate: 0.1
  }
};

export const useAdminStore = create<AdminStore>((set, get) => ({
  stats: mockStats,
  users: [],
  offers: [],
  isLoading: false,
  error: null,
  selectedTimeRange: '7d',

  setTimeRange: (range) => {
    set({ selectedTimeRange: range });
    get().fetchStats();
  },

  fetchStats: async () => {
    set({ isLoading: true });
    try {
      const { selectedTimeRange } = get();
      let daysToFetch = 30;
      
      switch (selectedTimeRange) {
        case '24h':
          daysToFetch = 1;
          break;
        case '7d':
          daysToFetch = 7;
          break;
        case '30d':
          daysToFetch = 30;
          break;
        case 'all':
          daysToFetch = 90;
          break;
      }
      
      const updatedStats = {
        ...mockStats,
        recentTransactions: generateMockTransactions(daysToFetch)
      };
      
      set({ stats: updatedStats, isLoading: false });
    } catch (error) {
      set({ error: 'Failed to fetch stats', isLoading: false });
    }
  },

  fetchUsers: async () => {
    set({ isLoading: true });
    try {
      const users = getMockUsers();
      set({ users: [...users], isLoading: false });
    } catch (error) {
      set({ error: 'Failed to fetch users', isLoading: false });
    }
  },

  fetchOffers: async () => {
    set({ isLoading: true });
    try {
      await useOfferStore.getState().fetchOffers(true); // Pass true to include all offers
      const offers = useOfferStore.getState().offers;
      set({ offers: [...offers], isLoading: false });
    } catch (error) {
      set({ error: 'Failed to fetch offers', isLoading: false });
    }
  },

  updateUserStatus: async (userId: string, status: User['status']) => {
    set({ isLoading: true });
    try {
      const updatedUsers = updateMockUserStatus(userId, status);
      set({ users: [...updatedUsers], isLoading: false });
    } catch (error) {
      set({ error: 'Failed to update user status', isLoading: false });
    }
  },

  updateOfferStatus: async (offerId: string, status: Offer['status']) => {
    set({ isLoading: true });
    try {
      const result = await useOfferStore.getState().updateOfferStatus(offerId, status);
      if (result.success) {
        await get().fetchOffers();
      } else {
        throw new Error(result.error);
      }
    } catch (error) {
      set({ error: 'Failed to update offer status', isLoading: false });
    }
  }
}));