import { create } from 'zustand';
import { AuthState, User, UserRole } from '../types';

// Admin credentials
const ADMIN_CREDENTIALS = {
  mobile: 'admin',
  password: 'admin123'
};

// Mock users data - stored in localStorage to persist between refreshes
const getStoredUsers = (): User[] => {
  const stored = localStorage.getItem('mockUsers');
  if (stored) {
    return JSON.parse(stored);
  }
  return [
    {
      id: '1',
      mobile: '9876543210',
      wallets: {},
      role: UserRole.USER,
      createdAt: '2024-01-01T00:00:00Z',
      status: 'active'
    },
    {
      id: '2',
      mobile: '9876543211',
      wallets: {},
      role: UserRole.USER,
      createdAt: '2024-01-02T00:00:00Z',
      status: 'active'
    },
    {
      id: '3',
      mobile: '9876543212',
      wallets: {},
      role: UserRole.USER,
      createdAt: '2024-01-03T00:00:00Z',
      status: 'active'
    }
  ];
};

const mockUsers = getStoredUsers();

// Save users to localStorage
const saveUsers = () => {
  localStorage.setItem('mockUsers', JSON.stringify(mockUsers));
};

// Export mock functions used by adminStore
export const getMockUsers = () => mockUsers;

export const updateMockUserStatus = (userId: string, status: User['status']) => {
  const userIndex = mockUsers.findIndex(u => u.id === userId);
  if (userIndex !== -1) {
    mockUsers[userIndex] = { ...mockUsers[userIndex], status };
    saveUsers();
  }
  return [...mockUsers];
};

interface AuthStore extends AuthState {
  login: (mobile: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (mobile: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  fetchUser: () => Promise<void>;
  isAdmin: () => boolean;
}

export const useAuthStore = create<AuthStore>((set, get) => ({
  user: null,
  isAuthenticated: false,
  isLoading: true,
  
  login: async (mobile, password) => {
    try {
      // Check for admin login
      if (mobile === ADMIN_CREDENTIALS.mobile && password === ADMIN_CREDENTIALS.password) {
        const adminUser: User = {
          id: 'admin',
          mobile: ADMIN_CREDENTIALS.mobile,
          wallets: {},
          role: UserRole.ADMIN,
          createdAt: new Date().toISOString(),
          status: 'active'
        };
        
        set({ 
          isAuthenticated: true, 
          user: adminUser,
          isLoading: false
        });

        // Store user in localStorage
        localStorage.setItem('currentUser', JSON.stringify(adminUser));
        return { success: true };
      }
      
      // Regular user login
      const user = mockUsers.find(u => u.mobile === mobile);
      if (user && user.status === 'active') {
        set({ 
          isAuthenticated: true, 
          user,
          isLoading: false
        });

        // Store user in localStorage
        localStorage.setItem('currentUser', JSON.stringify(user));
        return { success: true };
      }
      
      return { success: false, error: 'Invalid credentials or account is suspended' };
    } catch (error) {
      console.error('Login error:', error);
      return { success: false, error: 'Invalid credentials' };
    }
  },
  
  register: async (mobile, password) => {
    try {
      // Prevent registering with admin mobile
      if (mobile === ADMIN_CREDENTIALS.mobile) {
        return { success: false, error: 'This mobile number is not allowed' };
      }

      // Check if user already exists
      if (mockUsers.some(u => u.mobile === mobile)) {
        return { success: false, error: 'Mobile number already registered' };
      }
      
      // Create new user
      const newUser: User = {
        id: `user-${Date.now()}`,
        mobile,
        wallets: {},
        role: UserRole.USER,
        createdAt: new Date().toISOString(),
        status: 'active'
      };
      
      mockUsers.push(newUser);
      saveUsers(); // Save updated users list
      
      set({ 
        isAuthenticated: true, 
        user: newUser,
        isLoading: false
      });

      // Store user in localStorage
      localStorage.setItem('currentUser', JSON.stringify(newUser));
      
      return { success: true };
    } catch (error) {
      console.error('Registration error:', error);
      return { success: false, error: 'Registration failed' };
    }
  },
  
  logout: async () => {
    localStorage.removeItem('currentUser');
    set({ user: null, isAuthenticated: false });
  },
  
  fetchUser: async () => {
    try {
      set({ isLoading: true });
      
      // Check localStorage for existing user
      const storedUser = localStorage.getItem('currentUser');
      if (storedUser) {
        const user = JSON.parse(storedUser);
        set({ 
          user,
          isAuthenticated: true,
          isLoading: false
        });
      } else {
        set({ isLoading: false });
      }
    } catch (error) {
      console.error('Error fetching user:', error);
      set({ isAuthenticated: false, isLoading: false });
    }
  },

  isAdmin: () => {
    const { user } = get();
    return user?.role === UserRole.ADMIN;
  }
}));