import { create } from 'zustand';
import { Deal, DealStatus } from '../types';
import { useOfferStore } from './offerStore';
import toast from 'react-hot-toast';

interface DealState {
  deals: Deal[];
  isLoading: boolean;
  error: string | null;
}

interface DealActions {
  fetchUserDeals: (userId: string) => Promise<void>;
  createDeal: (params: { offerId: string; buyerId: string; sellerId: string }) => Promise<{ success: boolean; error?: string }>;
  updateDealStatus: (dealId: string, status: DealStatus) => Promise<{ success: boolean; error?: string }>;
}

type DealStore = DealState & DealActions;

// Get stored deals from localStorage
const getStoredDeals = (): Deal[] => {
  try {
    const stored = localStorage.getItem('deals');
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (error) {
    console.error('Error reading deals from localStorage:', error);
  }
  return [];
};

// Save deals to localStorage
const saveDeals = (deals: Deal[]) => {
  try {
    localStorage.setItem('deals', JSON.stringify(deals));
  } catch (error) {
    console.error('Error saving deals to localStorage:', error);
  }
};

// Generate a unique deal ID
const generateDealId = () => {
  return `BB-${Math.random().toString(36).substr(2, 5).toUpperCase()}`;
};

export const useDealStore = create<DealStore>((set, get) => ({
  deals: getStoredDeals(),
  isLoading: false,
  error: null,

  fetchUserDeals: async (userId: string) => {
    set({ isLoading: true, error: null });
    try {
      const allDeals = getStoredDeals();
      const userDeals = allDeals
        .filter(deal => deal.buyerId === userId || deal.sellerId === userId)
        .map(deal => ({
          ...deal,
          offer: useOfferStore.getState().offers.find(o => o.id === deal.offerId)
        }));
      
      set({ deals: userDeals, isLoading: false });
    } catch (error) {
      console.error('Error fetching deals:', error);
      set({ error: 'Failed to fetch deals', isLoading: false });
    }
  },

  createDeal: async ({ offerId, buyerId, sellerId }) => {
    try {
      const offer = useOfferStore.getState().offers.find(o => o.id === offerId);
      if (!offer) {
        return { success: false, error: 'Offer not found' };
      }

      // Check if deal already exists
      const existingDeal = getStoredDeals().find(d => 
        d.offerId === offerId && d.buyerId === buyerId && d.sellerId === sellerId
      );

      if (existingDeal) {
        return { success: false, error: 'You already have a deal for this offer' };
      }

      const newDeal: Deal = {
        id: generateDealId(),
        offerId,
        buyerId,
        sellerId,
        status: DealStatus.PENDING,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        offer
      };
      
      const allDeals = getStoredDeals();
      allDeals.push(newDeal);
      saveDeals(allDeals);
      
      // Update the offer status
      await useOfferStore.getState().updateOfferStatus(offerId, 'completed');
      
      // Update local state
      set(state => ({ deals: [...state.deals, newDeal] }));
      
      return { success: true };
    } catch (error) {
      console.error('Error creating deal:', error);
      return { success: false, error: 'Failed to create deal' };
    }
  },

  updateDealStatus: async (dealId: string, status: DealStatus) => {
    try {
      const allDeals = getStoredDeals();
      const updatedDeals = allDeals.map(deal =>
        deal.id === dealId
          ? { ...deal, status, updatedAt: new Date().toISOString() }
          : deal
      );
      
      saveDeals(updatedDeals);
      
      set(state => ({
        deals: state.deals.map(deal =>
          deal.id === dealId
            ? { ...deal, status, updatedAt: new Date().toISOString() }
            : deal
        )
      }));

      toast.success(`Deal status updated to ${status}`);
      
      return { success: true };
    } catch (error) {
      console.error('Error updating deal status:', error);
      return { success: false, error: 'Failed to update deal status' };
    }
  }
}));