import { create } from 'zustand';
import { Message } from '../types';
import toast from 'react-hot-toast';

interface MessageState {
  messages: Record<string, Message[]>;
  isLoading: boolean;
  error: string | null;
}

interface MessageActions {
  fetchMessages: (offerId: string) => Promise<void>;
  sendMessage: (offerId: string, content: string, isAdmin: boolean) => Promise<{ success: boolean; error?: string }>;
}

type MessageStore = MessageState & MessageActions;

// Get stored messages from localStorage
const getStoredMessages = (): Record<string, Message[]> => {
  try {
    const stored = localStorage.getItem('messages');
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (error) {
    console.error('Error reading messages from localStorage:', error);
  }
  return {};
};

// Save messages to localStorage
const saveMessages = (messages: Record<string, Message[]>) => {
  try {
    localStorage.setItem('messages', JSON.stringify(messages));
  } catch (error) {
    console.error('Error saving messages to localStorage:', error);
  }
};

export const useMessageStore = create<MessageStore>((set, get) => ({
  messages: getStoredMessages(),
  isLoading: false,
  error: null,

  fetchMessages: async (offerId: string) => {
    set({ isLoading: true, error: null });
    try {
      const messages = getStoredMessages();
      set({ messages, isLoading: false });
    } catch (error) {
      console.error('Error fetching messages:', error);
      set({ error: 'Failed to fetch messages', isLoading: false });
    }
  },

  sendMessage: async (offerId: string, content: string, isAdmin: boolean) => {
    try {
      const messages = getStoredMessages();
      const newMessage: Message = {
        id: `msg-${Date.now()}`,
        offerId,
        content,
        createdAt: new Date().toISOString(),
        isAdmin
      };

      messages[offerId] = [...(messages[offerId] || []), newMessage];
      saveMessages(messages);
      
      set({ messages });
      return { success: true };
    } catch (error) {
      console.error('Error sending message:', error);
      return { success: false, error: 'Failed to send message' };
    }
  }
}));