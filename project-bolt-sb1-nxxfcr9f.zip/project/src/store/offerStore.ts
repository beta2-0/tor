import { create } from 'zustand';
import { Offer, CryptoCoin, Country } from '../types';
import toast from 'react-hot-toast';

interface OfferState {
  offers: Offer[];
  userOffers: Offer[];
  isLoading: boolean;
  error: string | null;
}

interface OfferActions {
  fetchOffers: (includeAll?: boolean) => Promise<void>;
  fetchUserOffers: (userId: string) => Promise<void>;
  createOffer: (offer: Omit<Offer, 'id' | 'createdAt' | 'status'>) => Promise<{ success: boolean; error?: string }>;
  updateOfferStatus: (offerId: string, status: Offer['status']) => Promise<{ success: boolean; error?: string }>;
}

type OfferStore = OfferState & OfferActions;

// Get stored offers from localStorage
const getStoredOffers = (): Offer[] => {
  try {
    const stored = localStorage.getItem('offers');
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (error) {
    console.error('Error reading offers from localStorage:', error);
  }
  return [];
};

// Save offers to localStorage
const saveOffers = (offers: Offer[]) => {
  try {
    localStorage.setItem('offers', JSON.stringify(offers));
  } catch (error) {
    console.error('Error saving offers to localStorage:', error);
  }
};

export const useOfferStore = create<OfferStore>((set, get) => ({
  offers: getStoredOffers(),
  userOffers: [],
  isLoading: false,
  error: null,
  
  fetchOffers: async (includeAll = false) => {
    set({ isLoading: true, error: null });
    try {
      const offers = getStoredOffers();
      // Only filter active offers if includeAll is false
      set({ 
        offers: includeAll ? offers : offers.filter(o => o.status === 'active'), 
        isLoading: false 
      });
    } catch (error) {
      console.error('Error fetching offers:', error);
      set({ error: 'Failed to fetch offers', isLoading: false });
    }
  },
  
  fetchUserOffers: async (userId) => {
    set({ isLoading: true, error: null });
    try {
      const offers = getStoredOffers();
      const userOffers = offers.filter(offer => offer.userId === userId);
      set({ userOffers, isLoading: false });
    } catch (error) {
      console.error('Error fetching user offers:', error);
      set({ error: 'Failed to fetch your offers', isLoading: false });
    }
  },
  
  createOffer: async (offerData) => {
    try {
      // Generate a unique order ID (BB-XXXX format)
      const orderId = `BB-${Math.random().toString(36).substr(2, 4).toUpperCase()}`;
      
      const newOffer: Offer = {
        ...offerData,
        id: orderId,
        createdAt: new Date().toISOString(),
        status: 'active'
      };
      
      const offers = getStoredOffers();
      offers.push(newOffer);
      saveOffers(offers);
      
      set(state => ({ 
        offers: [...state.offers, newOffer],
        userOffers: [...state.userOffers, newOffer]
      }));
      
      toast.success('Sell offer created successfully!');
      return { success: true };
    } catch (error) {
      console.error('Error creating offer:', error);
      return { success: false, error: 'Failed to create offer' };
    }
  },
  
  updateOfferStatus: async (offerId, status) => {
    try {
      const offers = getStoredOffers();
      const updatedOffers = offers.map(offer =>
        offer.id === offerId ? { ...offer, status } : offer
      );
      
      saveOffers(updatedOffers);
      
      set(state => ({
        offers: state.offers.filter(o => o.id !== offerId || o.status === 'active'),
        userOffers: state.userOffers.map(offer =>
          offer.id === offerId ? { ...offer, status } : offer
        )
      }));
      
      return { success: true };
    } catch (error) {
      console.error('Error updating offer status:', error);
      return { success: false, error: 'Failed to update offer status' };
    }
  }
}));