import { CryptoCoin, Country } from '../types';

export const COINS = [
  CryptoCoin.BTC,
  CryptoCoin.ETH,
  CryptoCoin.USDT,
  CryptoCoin.BNB,
  CryptoCoin.USDC
];

export const COUNTRIES = [
  Country.INDIA,
  Country.USA,
  Country.NIGERIA
];

export const PAYMENT_METHODS = {
  [Country.INDIA]: [
    { id: 'upi', name: 'UPI', icon: '💸' },
    { id: 'bank_transfer', name: 'Bank Transfer', icon: '🏦' }
  ],
  [Country.USA]: [
    { id: 'paypal', name: 'PayPal', icon: '💰' },
    { id: 'zelle', name: 'Zelle', icon: '💵' }
  ],
  [Country.NIGERIA]: [
    { id: 'bank_transfer', name: 'Bank Transfer', icon: '🏦' },
    { id: 'flutterwave', name: 'Flutterwave', icon: '💲' }
  ]
};

export const getPaymentMethodsByCountry = (country: Country) => {
  return PAYMENT_METHODS[country] || [];
};

export const getCoinIcon = (coin: CryptoCoin): string => {
  const icons: Record<CryptoCoin, string> = {
    [CryptoCoin.BTC]: '₿',
    [CryptoCoin.ETH]: 'Ξ',
    [CryptoCoin.USDT]: '₮',
    [CryptoCoin.BNB]: 'BNB',
    [CryptoCoin.USDC]: '₮'
  };
  return icons[coin];
};