import React from 'react';
import { Deal, DealStatus } from '../../types';
import Button from '../ui/Button';
import { useDealStore } from '../../store/dealStore';

interface DealListProps {
  deals: Deal[];
}

const DealList: React.FC<DealListProps> = ({ deals }) => {
  const { updateDealStatus } = useDealStore();
  const [isLoading, setIsLoading] = React.useState<string | null>(null);

  const handleStatusUpdate = async (dealId: string, status: DealStatus) => {
    setIsLoading(dealId);
    try {
      await updateDealStatus(dealId, status);
    } finally {
      setIsLoading(null);
    }
  };

  const getStatusBadgeClass = (status: DealStatus) => {
    switch (status) {
      case DealStatus.PENDING:
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case DealStatus.PAID:
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case DealStatus.COMPLETED:
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
    }
  };

  if (!deals || deals.length === 0) {
    return (
      <div className="text-center py-12">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
          No deals found
        </h3>
        <p className="text-gray-600 dark:text-gray-400">
          Your completed and ongoing deals will appear here
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {deals.map((deal) => (
        <div
          key={deal.id}
          className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <div>
              <span className="text-sm font-medium text-gray-500 dark:text-gray-400">
                Deal ID:
              </span>
              <span className="ml-2 font-mono text-gray-900 dark:text-white">
                {deal.id}
              </span>
            </div>
            <span className={`
              inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
              ${getStatusBadgeClass(deal.status)}
            `}>
              {deal.status}
            </span>
          </div>

          {deal.offer && (
            <div className="space-y-3 mb-6">
              <div className="flex justify-between items-center">
                <span className="text-gray-500 dark:text-gray-400">Amount:</span>
                <span className="font-medium text-gray-900 dark:text-white">
                  {deal.offer.amount} {deal.offer.coin}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-500 dark:text-gray-400">Price:</span>
                <span className="font-medium text-gray-900 dark:text-white">
                  {deal.offer.price.toLocaleString()} {
                    deal.offer.country === 'India' ? 'INR' :
                    deal.offer.country === 'USA' ? 'USD' : 'NGN'
                  }
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-500 dark:text-gray-400">Payment Method:</span>
                <span className="font-medium text-gray-900 dark:text-white">
                  {deal.offer.paymentMethod.replace(/_/g, ' ')}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-500 dark:text-gray-400">Wallet Address:</span>
                <span className="font-mono text-sm text-gray-900 dark:text-white">
                  {deal.offer.walletAddress}
                </span>
              </div>
            </div>
          )}

          <div className="flex justify-end space-x-2">
            {deal.status === DealStatus.PENDING && (
              <Button
                variant="primary"
                size="sm"
                isLoading={isLoading === deal.id}
                onClick={() => handleStatusUpdate(deal.id, DealStatus.PAID)}
              >
                Mark as Paid
              </Button>
            )}
            {deal.status === DealStatus.PAID && (
              <Button
                variant="primary"
                size="sm"
                isLoading={isLoading === deal.id}
                onClick={() => handleStatusUpdate(deal.id, DealStatus.COMPLETED)}
              >
                Complete Deal
              </Button>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};

export default DealList;