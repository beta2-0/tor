import React, { useState } from 'react';
import { Copy, X, MessageCircle, Send } from 'lucide-react';
import toast from 'react-hot-toast';
import Button from '../ui/Button';
import { Offer } from '../../types';
import { useAuthStore } from '../../store/authStore';
import { useDealStore } from '../../store/dealStore';

interface DealModalProps {
  offer: Offer;
  onClose: () => void;
}

const DealModal: React.FC<DealModalProps> = ({ offer, onClose }) => {
  const { user } = useAuthStore();
  const { createDeal } = useDealStore();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleCreateDeal = async () => {
    if (!user) return;

    setIsLoading(true);
    setError(null);

    try {
      const { success, error } = await createDeal({
        offerId: offer.id,
        buyerId: user.id,
        sellerId: offer.userId
      });

      if (success) {
        toast.success('Deal created! Contact admin to complete the transaction.');
        onClose();
      } else {
        setError(error || 'Failed to create deal');
      }
    } catch (err) {
      setError('An unexpected error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  // Admin contact details
  const adminWhatsApp = '919876543210';
  const adminTelegram = 'cryptosell_admin';
  
  const handleCopyOrderId = () => {
    navigator.clipboard.writeText(offer.id);
    toast.success('Order ID copied to clipboard!');
  };
  
  const getWhatsAppLink = () => {
    const message = encodeURIComponent(`I want to buy crypto\nOrder ID: ${offer.id}\nAmount: ${offer.amount} ${offer.coin}\nPrice: ${offer.price} ${offer.country === 'India' ? 'INR' : offer.country === 'USA' ? 'USD' : 'NGN'}`);
    return `https://wa.me/${adminWhatsApp}?text=${message}`;
  };
  
  const getTelegramLink = () => {
    return `https://t.me/${adminTelegram}?start=${offer.id}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-50">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-md w-full">
        <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Complete Your Purchase
          </h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500 dark:hover:text-gray-300"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-4">
          <div className="space-y-4">
            <div>
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
                Order ID:
              </p>
              <div className="mt-1 flex items-center space-x-2">
                <code className="block px-3 py-2 text-lg font-mono bg-gray-100 dark:bg-gray-700 rounded">
                  {offer.id}
                </code>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleCopyOrderId}
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div>
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
                Order Summary:
              </p>
              <div className="mt-2 space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Amount:</span>
                  <span className="font-medium text-gray-900 dark:text-white">
                    {offer.amount} {offer.coin}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Price:</span>
                  <span className="font-medium text-gray-900 dark:text-white">
                    {offer.price.toLocaleString()} {
                      offer.country === 'India' ? 'INR' :
                      offer.country === 'USA' ? 'USD' : 'NGN'
                    }
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Payment Method:</span>
                  <span className="font-medium text-gray-900 dark:text-white">
                    {offer.paymentMethod.replace(/_/g, ' ')}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Wallet Address:</span>
                  <span className="font-mono text-sm text-gray-900 dark:text-white break-all">
                    {offer.walletAddress}
                  </span>
                </div>
              </div>
            </div>

            {error && (
              <div className="p-3 bg-red-100 text-red-700 rounded-md text-sm">
                {error}
              </div>
            )}

            <div className="bg-blue-50 dark:bg-blue-900/30 p-4 rounded-lg">
              <p className="text-sm text-blue-800 dark:text-blue-200">
                Click "Create Deal" to start the transaction, then contact our admin via WhatsApp or Telegram to complete the purchase.
              </p>
            </div>

            <Button
              variant="primary"
              fullWidth
              isLoading={isLoading}
              onClick={handleCreateDeal}
            >
              Create Deal
            </Button>

            <div className="grid grid-cols-2 gap-4">
              <a 
                href={getWhatsAppLink()} 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-full"
              >
                <Button
                  variant="outline"
                  fullWidth
                  className="bg-green-500 hover:bg-green-600 text-white border-0"
                >
                  <MessageCircle className="h-4 w-4 mr-2" />
                  WhatsApp
                </Button>
              </a>
              
              <a 
                href={getTelegramLink()} 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-full"
              >
                <Button
                  variant="outline"
                  fullWidth
                  className="bg-blue-500 hover:bg-blue-600 text-white border-0"
                >
                  <Send className="h-4 w-4 mr-2" />
                  Telegram
                </Button>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DealModal;