import React, { useState } from 'react';
import { Copy, X, Send } from 'lucide-react';
import toast from 'react-hot-toast';
import Button from '../ui/Button';
import { Offer } from '../../types';

interface OrderModalProps {
  offer: Offer;
  onClose: () => void;
}

const OrderModal: React.FC<OrderModalProps> = ({ offer, onClose }) => {
  const [isLoading, setIsLoading] = useState(false);
  
  // Format order ID as BB-XXXXX where XXXXX is first 5 chars of offer ID
  const orderId = offer.id;
  
  // Admin Telegram username
  const adminTelegram = 'cryptosell_admin';
  
  const handleCopyOrderId = () => {
    navigator.clipboard.writeText(orderId);
    toast.success('Order ID copied to clipboard!');
  };
  
  const getTelegramLink = () => {
    const message = encodeURIComponent(`I want to buy crypto\nOrder ID: ${orderId}\nAmount: ${offer.amount} ${offer.coin}\nPrice: ${offer.price} ${offer.country === 'India' ? 'INR' : offer.country === 'USA' ? 'USD' : 'NGN'}`);
    return `https://t.me/${adminTelegram}?start=${orderId}&text=${message}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-50">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-md w-full">
        <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Complete Your Purchase
          </h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500 dark:hover:text-gray-300"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-4">
          <div className="space-y-4">
            <div>
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
                Your Order ID:
              </p>
              <div className="mt-1 flex items-center space-x-2">
                <code className="block px-3 py-2 text-lg font-mono bg-gray-100 dark:bg-gray-700 rounded text-gray-900 dark:text-white">
                  {orderId}
                </code>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleCopyOrderId}
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div>
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
                Order Summary:
              </p>
              <div className="mt-2 space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Amount:</span>
                  <span className="font-medium text-gray-900 dark:text-white">
                    {offer.amount} {offer.coin}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Price:</span>
                  <span className="font-medium text-gray-900 dark:text-white">
                    {offer.price.toLocaleString()} {
                      offer.country === 'India' ? 'INR' :
                      offer.country === 'USA' ? 'USD' : 'NGN'
                    }
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Payment Method:</span>
                  <span className="font-medium text-gray-900 dark:text-white">
                    {offer.paymentMethod.replace(/_/g, ' ')}
                  </span>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 dark:bg-blue-900/30 p-4 rounded-lg">
              <p className="text-sm text-blue-800 dark:text-blue-200">
                To complete your purchase, click the button below to contact our admin on Telegram. Make sure to share your Order ID when messaging.
              </p>
            </div>

            <div className="flex justify-center">
              <a 
                href={getTelegramLink()} 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-full"
              >
                <Button
                  variant="primary"
                  fullWidth
                  className="bg-[#0088cc] hover:bg-[#0077b5] border-0"
                >
                  <Send className="h-4 w-4 mr-2" />
                  Contact Admin on Telegram
                </Button>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderModal;