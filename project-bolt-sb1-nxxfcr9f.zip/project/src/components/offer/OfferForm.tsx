import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Input from '../ui/Input';
import Select from '../ui/Select';
import Button from '../ui/Button';
import { CryptoCoin, Country } from '../../types';
import { COUNTRIES, getPaymentMethodsByCountry } from '../../constants';
import { useAuthStore } from '../../store/authStore';
import { useOfferStore } from '../../store/offerStore';
import toast from 'react-hot-toast';

interface OfferFormProps {
  initialCoin: CryptoCoin;
}

const OfferForm: React.FC<OfferFormProps> = ({ initialCoin }) => {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const { createOffer } = useOfferStore();
  
  const [country, setCountry] = useState<Country>(Country.INDIA);
  const [price, setPrice] = useState<string>('');
  const [amount, setAmount] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<string>('');
  const [walletAddress, setWalletAddress] = useState<string>('');
  
  const [paymentMethods, setPaymentMethods] = useState<{value: string; label: string}[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  useEffect(() => {
    const methods = getPaymentMethodsByCountry(country).map(method => ({
      value: method.id,
      label: `${method.icon} ${method.name}`
    }));
    
    setPaymentMethods(methods);
    
    if (methods.length > 0 && !methods.some(m => m.value === paymentMethod)) {
      setPaymentMethod(methods[0].value);
    }
  }, [country, paymentMethod]);
  
  const validate = () => {
    const newErrors: Record<string, string> = {};
    
    if (!country) newErrors.country = 'Please select a country';
    if (!price || isNaN(parseFloat(price)) || parseFloat(price) <= 0) {
      newErrors.price = 'Please enter a valid price';
    }
    if (!amount || isNaN(parseFloat(amount)) || parseFloat(amount) <= 0) {
      newErrors.amount = 'Please enter a valid amount';
    }
    if (!paymentMethod) newErrors.paymentMethod = 'Please select a payment method';
    if (!walletAddress || walletAddress.trim() === '') {
      newErrors.walletAddress = 'Please enter your wallet address';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validate() || !user) return;
    
    setIsSubmitting(true);
    setErrors({});
    
    try {
      const { success, error } = await createOffer({
        userId: user.id,
        coin: initialCoin,
        country,
        price: parseFloat(price),
        amount: parseFloat(amount),
        paymentMethod,
        walletAddress,
        type: 'sell'
      });
      
      if (success) {
        toast.success('Sell offer created successfully!');
        navigate('/dashboard');
      } else {
        setErrors({ form: error || 'Failed to create offer' });
      }
    } catch (error) {
      setErrors({ form: 'An unexpected error occurred' });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md max-w-2xl mx-auto">
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
          Create {initialCoin} Sell Offer
        </h2>
        <p className="mt-2 text-gray-600 dark:text-gray-400">
          Fill in the details below to list your {initialCoin} for sale
        </p>
      </div>
      
      {errors.form && (
        <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-md">
          {errors.form}
        </div>
      )}
      
      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Select
            label="Country"
            options={COUNTRIES.map(c => ({ value: c, label: c }))}
            value={country}
            onChange={(value) => setCountry(value as Country)}
            error={errors.country}
            fullWidth
          />
          
          <Input
            label="Price"
            type="number"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            placeholder={`Price per ${initialCoin} in local currency`}
            error={errors.price}
            fullWidth
          />
          
          <Input
            label="Amount"
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder={`Amount of ${initialCoin} to sell`}
            error={errors.amount}
            fullWidth
          />
          
          <Select
            label="Payment Method"
            options={paymentMethods}
            value={paymentMethod}
            onChange={setPaymentMethod}
            error={errors.paymentMethod}
            fullWidth
          />
          
          <div className="md:col-span-2">
            <Input
              label="Wallet Address"
              type="text"
              value={walletAddress}
              onChange={(e) => setWalletAddress(e.target.value)}
              placeholder={`Your ${initialCoin} wallet address`}
              error={errors.walletAddress}
              fullWidth
            />
          </div>
        </div>
        
        <div className="flex items-center justify-end mt-6">
          <Button
            type="button"
            variant="outline"
            onClick={() => navigate('/dashboard')}
            className="mr-4"
          >
            Cancel
          </Button>
          <Button
            type="submit"
            variant="primary"
            isLoading={isSubmitting}
          >
            Create Sell Offer
          </Button>
        </div>
      </form>
    </div>
  );
};

export default OfferForm;