import React, { useState } from 'react';
import { Offer } from '../../types';
import { getCoinIcon } from '../../constants';
import Button from '../ui/Button';
import { useAuthStore } from '../../store/authStore';
import { useOfferStore } from '../../store/offerStore';
import DealModal from '../deal/DealModal';

interface OfferCardProps {
  offer: Offer;
  isUserOffer?: boolean;
}

const OfferCard: React.FC<OfferCardProps> = ({ offer, isUserOffer = false }) => {
  const { isAuthenticated } = useAuthStore();
  const { updateOfferStatus } = useOfferStore();
  const [showDealModal, setShowDealModal] = useState(false);
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };
  
  const handleCancelOffer = async () => {
    if (window.confirm('Are you sure you want to cancel this offer?')) {
      await updateOfferStatus(offer.id, 'cancelled');
    }
  };
  
  // Format price based on country
  const formatPrice = () => {
    switch (offer.country) {
      case 'India':
        return `₹${offer.price.toLocaleString()}`;
      case 'USA':
        return `$${offer.price.toLocaleString()}`;
      case 'Nigeria':
        return `₦${offer.price.toLocaleString()}`;
      default:
        return offer.price.toLocaleString();
    }
  };
  
  // Get payment method icon
  const getPaymentMethodIcon = () => {
    const icons: Record<string, string> = {
      'upi': '💸',
      'bank_transfer_india': '🏦',
      'paypal': '💰',
      'zelle': '💵',
      'bank_transfer_nigeria': '🏦',
      'flutterwave': '💲',
    };
    
    return icons[offer.paymentMethod] || '💳';
  };
  
  return (
    <>
      <div className={`
        bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden
        transition-all duration-300 hover:shadow-lg border-l-4
        ${offer.status === 'active' ? 'border-green-500' : 
          offer.status === 'completed' ? 'border-blue-500' : 'border-red-500'}
      `}>
        <div className="p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center">
              <span className="text-2xl mr-2">{getCoinIcon(offer.coin)}</span>
              <h3 className="text-lg font-bold text-gray-800 dark:text-white">
                {offer.coin}
              </h3>
            </div>
            <div className="px-2 py-1 rounded text-xs font-medium uppercase tracking-wide 
                           text-white bg-gradient-to-r from-blue-600 to-purple-600">
              SELL
            </div>
          </div>
          
          <div className="space-y-2 mb-4">
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Price:</span>
              <span className="font-semibold text-gray-800 dark:text-white">{formatPrice()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Amount:</span>
              <span className="font-semibold text-gray-800 dark:text-white">{offer.amount}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Payment Method:</span>
              <span className="font-semibold text-gray-800 dark:text-white">
                {getPaymentMethodIcon()} {offer.paymentMethod.replace(/_/g, ' ')}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Country:</span>
              <span className="font-semibold text-gray-800 dark:text-white">{offer.country}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Date:</span>
              <span className="font-semibold text-gray-800 dark:text-white">{formatDate(offer.createdAt)}</span>
            </div>
          </div>
          
          {isUserOffer ? (
            <div className="mt-4">
              {offer.status === 'active' && (
                <Button 
                  variant="danger" 
                  size="sm" 
                  fullWidth
                  onClick={handleCancelOffer}
                >
                  Cancel Offer
                </Button>
              )}
              {offer.status === 'cancelled' && (
                <div className="text-center text-red-500 font-medium">
                  Cancelled
                </div>
              )}
              {offer.status === 'completed' && (
                <div className="text-center text-green-500 font-medium">
                  Completed
                </div>
              )}
            </div>
          ) : (
            <div className="mt-4">
              {isAuthenticated ? (
                <Button 
                  variant="primary" 
                  size="md" 
                  fullWidth
                  disabled={offer.status !== 'active'}
                  onClick={() => setShowDealModal(true)}
                >
                  I Want to Buy
                </Button>
              ) : (
                <Button 
                  variant="primary" 
                  size="md" 
                  fullWidth
                  onClick={() => window.location.href = '/login'}
                >
                  Login to Buy
                </Button>
              )}
            </div>
          )}
        </div>
      </div>

      {showDealModal && (
        <DealModal
          offer={offer}
          onClose={() => setShowDealModal(false)}
        />
      )}
    </>
  );
};

export default OfferCard;