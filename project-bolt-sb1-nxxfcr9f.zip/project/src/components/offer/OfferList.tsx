import React, { useState, useEffect } from 'react';
import { Offer, Country, CryptoCoin } from '../../types';
import OfferCard from './OfferCard';
import Select from '../ui/Select';
import { COINS, COUNTRIES } from '../../constants';

interface OfferListProps {
  offers: Offer[];
  isUserOffers?: boolean;
}

const OfferList: React.FC<OfferListProps> = ({ offers, isUserOffers = false }) => {
  const [filteredOffers, setFilteredOffers] = useState<Offer[]>(offers);
  const [selectedCountry, setSelectedCountry] = useState<string>('all');
  const [selectedCoin, setSelectedCoin] = useState<string>('all');
  
  useEffect(() => {
    filterOffers();
  }, [offers, selectedCountry, selectedCoin]);
  
  const filterOffers = () => {
    let filtered = [...offers];
    
    if (selectedCountry !== 'all') {
      filtered = filtered.filter(offer => offer.country === selectedCountry);
    }
    
    if (selectedCoin !== 'all') {
      filtered = filtered.filter(offer => offer.coin === selectedCoin);
    }
    
    setFilteredOffers(filtered);
  };
  
  const countryOptions = [
    { value: 'all', label: 'All Countries' },
    ...COUNTRIES.map(country => ({ value: country, label: country }))
  ];
  
  const coinOptions = [
    { value: 'all', label: 'All Coins' },
    ...COINS.map(coin => ({ value: coin, label: coin }))
  ];
  
  return (
    <div>
      <div className="mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <Select
            label="Filter by Country"
            options={countryOptions}
            value={selectedCountry}
            onChange={setSelectedCountry}
          />
          <Select
            label="Filter by Coin"
            options={coinOptions}
            value={selectedCoin}
            onChange={setSelectedCoin}
          />
        </div>
      </div>
      
      {filteredOffers.length === 0 ? (
        <div className="text-center py-10">
          <p className="text-gray-600 dark:text-gray-400">No offers found</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredOffers.map(offer => (
            <OfferCard 
              key={offer.id} 
              offer={offer} 
              isUserOffer={isUserOffers}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default OfferList;