import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MessageCircle, Send, GitBranch as BrandTelegram } from 'lucide-react';
import Layout from '../components/layout/Layout';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import { useAuthStore } from '../store/authStore';
import { useOfferStore } from '../store/offerStore';
import { useMessageStore } from '../store/messageStore';

const Deals: React.FC = () => {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuthStore();
  const { userOffers, fetchUserOffers } = useOfferStore();
  const { messages, fetchMessages, sendMessage } = useMessageStore();
  const [selectedOfferId, setSelectedOfferId] = useState<string | null>(null);
  const [newMessage, setNewMessage] = useState('');
  
  // Telegram channel details
  const TELEGRAM_USERNAME = 'cryptosell_admin';
  
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    if (user) {
      fetchUserOffers(user.id);
    }
  }, [isAuthenticated, user, navigate, fetchUserOffers]);

  useEffect(() => {
    if (selectedOfferId) {
      fetchMessages(selectedOfferId);
    }
  }, [selectedOfferId, fetchMessages]);

  const handleSendMessage = async (offerId: string) => {
    if (!newMessage.trim()) return;

    const { success } = await sendMessage(offerId, newMessage, false);
    if (success) {
      setNewMessage('');
    }
  };

  const getTelegramLink = (offer: typeof userOffers[0]) => {
    const message = encodeURIComponent(
      `Order ID: ${offer.id}\nAmount: ${offer.amount} ${offer.coin}\nPrice: ${offer.price} ${
        offer.country === 'India' ? 'INR' : offer.country === 'USA' ? 'USD' : 'NGN'
      }`
    );
    return `https://t.me/${TELEGRAM_USERNAME}?start=${offer.id}&text=${message}`;
  };

  return (
    <Layout>
      <div className="bg-gray-100 dark:bg-gray-900 min-h-screen py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-800 dark:text-white">My Sell Orders</h1>
            <p className="mt-2 text-gray-600 dark:text-gray-400">
              Track and manage your sell orders
            </p>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <div className="space-y-4">
              {userOffers.length === 0 ? (
                <div className="text-center py-12">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                    No sell orders found
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    Your sell orders will appear here
                  </p>
                </div>
              ) : (
                userOffers.map(offer => (
                  <div
                    key={offer.id}
                    className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-6"
                  >
                    <div className="flex justify-between items-center mb-4">
                      <div className="flex items-center space-x-4">
                        <div>
                          <span className="text-sm font-medium text-gray-500 dark:text-gray-400">
                            Order ID:
                          </span>
                          <span className="ml-2 font-mono text-gray-900 dark:text-white">
                            {offer.id}
                          </span>
                        </div>
                        <a
                          href={getTelegramLink(offer)}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center px-3 py-1.5 bg-[#229ED9] hover:bg-[#1E8BC3] text-white rounded-md transition-colors"
                        >
                          <BrandTelegram className="h-5 w-5 mr-1.5" />
                          <span className="text-sm font-medium">Send to Telegram</span>
                        </a>
                      </div>
                      <span className={`
                        inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                        ${offer.status === 'active' 
                          ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                          : offer.status === 'completed'
                          ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
                          : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                        }
                      `}>
                        {offer.status}
                      </span>
                    </div>
                    
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-500 dark:text-gray-400">Amount:</span>
                        <span className="font-medium text-gray-900 dark:text-white">
                          {offer.amount} {offer.coin}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-500 dark:text-gray-400">Price:</span>
                        <span className="font-medium text-gray-900 dark:text-white">
                          {offer.price.toLocaleString()} {
                            offer.country === 'India' ? 'INR' :
                            offer.country === 'USA' ? 'USD' : 'NGN'
                          }
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-500 dark:text-gray-400">Payment Method:</span>
                        <span className="font-medium text-gray-900 dark:text-white">
                          {offer.paymentMethod.replace(/_/g, ' ')}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-500 dark:text-gray-400">Created:</span>
                        <span className="font-medium text-gray-900 dark:text-white">
                          {new Date(offer.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>

                    {/* Messages Section */}
                    <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center">
                          <MessageCircle className="h-5 w-5 mr-2" />
                          Messages
                        </h3>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setSelectedOfferId(selectedOfferId === offer.id ? null : offer.id)}
                        >
                          {selectedOfferId === offer.id ? 'Hide Messages' : 'Show Messages'}
                        </Button>
                      </div>

                      {selectedOfferId === offer.id && (
                        <div className="space-y-4">
                          <div className="h-64 overflow-y-auto bg-gray-50 dark:bg-gray-900 rounded-lg p-4">
                            {messages[offer.id]?.length ? (
                              messages[offer.id].map(message => (
                                <div
                                  key={message.id}
                                  className={`mb-4 ${message.isAdmin ? 'text-right' : 'text-left'}`}
                                >
                                  <div className={`
                                    inline-block rounded-lg px-4 py-2 max-w-[80%]
                                    ${message.isAdmin 
                                      ? 'bg-blue-500 text-white' 
                                      : 'bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-white'}
                                  `}>
                                    <p className="text-sm">{message.content}</p>
                                    <p className="text-xs mt-1 opacity-70">
                                      {new Date(message.createdAt).toLocaleTimeString()}
                                    </p>
                                  </div>
                                </div>
                              ))
                            ) : (
                              <p className="text-center text-gray-500 dark:text-gray-400">
                                No messages yet
                              </p>
                            )}
                          </div>

                          <div className="flex space-x-2">
                            <Input
                              value={newMessage}
                              onChange={(e) => setNewMessage(e.target.value)}
                              placeholder="Type your message..."
                              fullWidth
                            />
                            <Button
                              variant="primary"
                              onClick={() => handleSendMessage(offer.id)}
                              disabled={!newMessage.trim()}
                            >
                              <Send className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Deals;