import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Layout from '../components/layout/Layout';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import { useAuthStore } from '../store/authStore';
import { CryptoCoin } from '../types';
import { COINS } from '../constants';

const Profile: React.FC = () => {
  const { user, isAuthenticated } = useAuthStore();
  const navigate = useNavigate();
  
  const [newWallet, setNewWallet] = useState<string>('');
  const [selectedCoin, setSelectedCoin] = useState<CryptoCoin>(CryptoCoin.BTC);
  
  // Redirect to login if not authenticated
  React.useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
    }
  }, [isAuthenticated, navigate]);
  
  if (!isAuthenticated || !user) {
    return null;
  }
  
  // This is a mock function, in a real app you would save to Supabase
  const handleAddWallet = () => {
    if (!newWallet.trim()) return;
    
    alert(`Wallet added: ${newWallet} for ${selectedCoin}`);
    setNewWallet('');
  };
  
  return (
    <Layout>
      <div className="bg-gray-100 dark:bg-gray-900 py-8">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700">
              <h1 className="text-2xl font-bold text-gray-800 dark:text-white">Profile</h1>
            </div>
            
            <div className="p-6">
              <div className="mb-6">
                <h2 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">Account Information</h2>
                <div className="space-y-4">
                  <div>
                    <span className="block text-sm font-medium text-gray-600 dark:text-gray-400">Mobile Number</span>
                    <span className="block mt-1 text-lg font-semibold text-gray-800 dark:text-white">{user.mobile}</span>
                  </div>
                  
                  <div>
                    <span className="block text-sm font-medium text-gray-600 dark:text-gray-400">Account ID</span>
                    <span className="block mt-1 text-lg font-semibold text-gray-800 dark:text-white">{user.id}</span>
                  </div>
                </div>
              </div>
              
              <div className="mb-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                <h2 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">Wallet Addresses</h2>
                
                <div className="mb-6">
                  <div className="flex items-end space-x-4">
                    <div className="flex-1">
                      <label className="block text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">
                        Coin
                      </label>
                      <select
                        value={selectedCoin}
                        onChange={(e) => setSelectedCoin(e.target.value as CryptoCoin)}
                        className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-900 dark:text-white"
                      >
                        {COINS.map((coin) => (
                          <option key={coin} value={coin}>{coin}</option>
                        ))}
                      </select>
                    </div>
                    <div className="flex-1">
                      <Input
                        label="Wallet Address"
                        value={newWallet}
                        onChange={(e) => setNewWallet(e.target.value)}
                        placeholder="Enter your wallet address"
                        fullWidth
                      />
                    </div>
                    <Button
                      variant="primary"
                      onClick={handleAddWallet}
                      disabled={!newWallet.trim()}
                    >
                      Add
                    </Button>
                  </div>
                </div>
                
                <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-4">
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    No wallet addresses saved yet. Add your wallet addresses to quickly create sell offers.
                  </p>
                </div>
              </div>
              
              <div className="pt-6 border-t border-gray-200 dark:border-gray-700">
                <h2 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">Security</h2>
                
                <Button
                  variant="outline"
                  className="mr-4"
                >
                  Change Password
                </Button>
                
                <Button
                  variant="danger"
                >
                  Delete Account
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Profile;