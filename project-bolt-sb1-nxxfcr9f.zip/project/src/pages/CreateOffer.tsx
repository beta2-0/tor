import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import Layout from '../components/layout/Layout';
import OfferForm from '../components/offer/OfferForm';
import { useAuthStore } from '../store/authStore';
import { CryptoCoin } from '../types';

const CreateOffer: React.FC = () => {
  const { isAuthenticated } = useAuthStore();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const selectedCoin = searchParams.get('coin') as CryptoCoin;
  
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }
    
    if (!selectedCoin || !Object.values(CryptoCoin).includes(selectedCoin)) {
      navigate('/dashboard');
    }
  }, [isAuthenticated, navigate, selectedCoin]);
  
  if (!isAuthenticated || !selectedCoin) {
    return null;
  }
  
  return (
    <Layout>
      <div className="bg-gray-100 dark:bg-gray-900 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-800 dark:text-white">
              Create {selectedCoin} Sell Offer
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mt-2">
              Fill in the details below to create your sell offer. This will be visible to potential buyers.
            </p>
          </div>
          
          <OfferForm initialCoin={selectedCoin} />
        </div>
      </div>
    </Layout>
  );
};

export default CreateOffer;