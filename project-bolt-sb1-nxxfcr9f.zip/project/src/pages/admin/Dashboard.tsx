import React, { useEffect } from 'react';
import { 
  Users as UsersIcon, 
  UserCheck, 
  Tag, 
  Check as TagCheck, 
  TrendingUp,
  Clock,
  Activity,
  AlertTriangle
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar
} from 'recharts';
import AdminLayout from '../../components/layout/AdminLayout';
import Button from '../../components/ui/Button';
import { useAdminStore } from '../../store/adminStore';
import { useAuthStore } from '../../store/authStore';
import { useOfferStore } from '../../store/offerStore';

const StatCard: React.FC<{
  title: string;
  value: string;
  icon: React.ReactNode;
  trend?: string;
  trendUp?: boolean;
}> = ({ title, value, icon, trend, trendUp }) => (
  <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
    <div className="flex items-center">
      <div className="p-3 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300">
        {icon}
      </div>
      <div className="ml-5">
        <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{title}</p>
        <h3 className="text-xl font-semibold text-gray-900 dark:text-white mt-1">{value}</h3>
        {trend && (
          <p className={`text-sm mt-1 ${trendUp ? 'text-green-600' : 'text-red-600'}`}>
            {trend}
          </p>
        )}
      </div>
    </div>
  </div>
);

const TimeRangeSelector: React.FC<{
  selected: string;
  onChange: (range: '24h' | '7d' | '30d' | 'all') => void;
}> = ({ selected, onChange }) => (
  <div className="flex space-x-2">
    {[
      { value: '24h', label: '24h' },
      { value: '7d', label: '7D' },
      { value: '30d', label: '30D' },
      { value: 'all', label: 'All' }
    ].map(({ value, label }) => (
      <Button
        key={value}
        variant={selected === value ? 'primary' : 'outline'}
        size="sm"
        onClick={() => onChange(value as '24h' | '7d' | '30d' | 'all')}
      >
        {label}
      </Button>
    ))}
  </div>
);

const Dashboard: React.FC = () => {
  const { users } = useAuthStore();
  const { offers } = useOfferStore();
  const { selectedTimeRange, setTimeRange, fetchStats } = useAdminStore();
  
  useEffect(() => {
    fetchStats();
  }, [fetchStats]);

  // Calculate real-time stats
  const activeUsers = users?.filter(u => u.status === 'active')?.length ?? 0;
  const totalUsers = users?.length ?? 0;
  const activeOffers = offers?.filter(o => o.status === 'active')?.length ?? 0;
  const totalOffers = offers?.length ?? 0;
  const completedOffers = offers?.filter(o => o.status === 'completed')?.length ?? 0;
  const completionRate = totalOffers ? Math.round((completedOffers / totalOffers) * 100) : 0;

  // Calculate average amount per offer
  const averageAmount = offers?.length
    ? Math.round(offers.reduce((sum, offer) => sum + offer.amount, 0) / offers.length)
    : 0;

  // Get popular coins
  const coinCounts = offers?.reduce((acc, offer) => {
    acc[offer.coin] = (acc[offer.coin] || 0) + 1;
    return acc;
  }, {} as Record<string, number>) ?? {};

  const popularCoins = Object.entries(coinCounts)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 3)
    .map(([coin]) => coin);

  // Get popular countries
  const countryCounts = offers?.reduce((acc, offer) => {
    acc[offer.country] = (acc[offer.country] || 0) + 1;
    return acc;
  }, {} as Record<string, number>) ?? {};

  const popularCountries = Object.entries(countryCounts)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 3)
    .map(([country]) => country);

  // Generate transaction data
  const generateTransactionData = () => {
    const days = selectedTimeRange === '24h' ? 1 
      : selectedTimeRange === '7d' ? 7 
      : selectedTimeRange === '30d' ? 30 
      : 90;

    const data = [];
    const now = new Date();
    for (let i = days - 1; i >= 0; i--) {
      const date = new Date(now);
      date.setDate(date.getDate() - i);
      
      // Filter offers for this date
      const dayOffers = offers?.filter(offer => {
        const offerDate = new Date(offer.createdAt);
        return offerDate.toDateString() === date.toDateString();
      }) ?? [];

      // Calculate total volume for the day
      const volume = dayOffers.reduce((sum, offer) => sum + (offer.price * offer.amount), 0);

      data.push({
        date: date.toISOString().split('T')[0],
        volume: Math.round(volume)
      });
    }

    return data;
  };

  return (
    <AdminLayout>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Dashboard</h1>
        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
          Overview of platform statistics and performance
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard
          title="Total Users"
          value={totalUsers.toLocaleString()}
          icon={<UsersIcon className="h-6 w-6" />}
          trend={`+${users?.filter(u => {
            const createdAt = new Date(u.createdAt);
            const today = new Date();
            return createdAt.toDateString() === today.toDateString();
          })?.length ?? 0} today`}
          trendUp
        />
        <StatCard
          title="Active Users"
          value={activeUsers.toLocaleString()}
          icon={<UserCheck className="h-6 w-6" />}
          trend={`${Math.round((activeUsers / totalUsers) * 100)}% of total users`}
          trendUp
        />
        <StatCard
          title="Total Offers"
          value={totalOffers.toLocaleString()}
          icon={<Tag className="h-6 w-6" />}
          trend={`${completionRate}% completion rate`}
          trendUp
        />
        <StatCard
          title="Active Offers"
          value={activeOffers.toLocaleString()}
          icon={<TagCheck className="h-6 w-6" />}
          trend={`Avg. ${averageAmount.toLocaleString()} per offer`}
          trendUp
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* Transaction Volume Chart */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                Transaction Volume
              </h2>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Total transaction volume over time
              </p>
            </div>
            <TimeRangeSelector
              selected={selectedTimeRange}
              onChange={setTimeRange}
            />
          </div>
          
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={generateTransactionData()}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="date" 
                  stroke="#6B7280"
                  tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                />
                <YAxis 
                  stroke="#6B7280"
                  tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1F2937',
                    border: 'none',
                    borderRadius: '0.5rem',
                    color: '#F3F4F6'
                  }}
                  formatter={(value: number) => [`$${value.toLocaleString()}`, 'Volume']}
                />
                <Line
                  type="monotone"
                  dataKey="volume"
                  stroke="#3B82F6"
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* User Growth Chart */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                User Growth
              </h2>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                New user registrations by period
              </p>
            </div>
          </div>
          
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={[
                  { 
                    period: 'Daily', 
                    users: users?.filter(u => {
                      const createdAt = new Date(u.createdAt);
                      const today = new Date();
                      return createdAt.toDateString() === today.toDateString();
                    })?.length ?? 0
                  },
                  { 
                    period: 'Weekly', 
                    users: users?.filter(u => {
                      const createdAt = new Date(u.createdAt);
                      const weekAgo = new Date();
                      weekAgo.setDate(weekAgo.getDate() - 7);
                      return createdAt >= weekAgo;
                    })?.length ?? 0
                  },
                  { 
                    period: 'Monthly', 
                    users: users?.filter(u => {
                      const createdAt = new Date(u.createdAt);
                      const monthAgo = new Date();
                      monthAgo.setMonth(monthAgo.getMonth() - 1);
                      return createdAt >= monthAgo;
                    })?.length ?? 0
                  }
                ]}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="period" />
                <YAxis />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1F2937',
                    border: 'none',
                    borderRadius: '0.5rem',
                    color: '#F3F4F6'
                  }}
                />
                <Bar dataKey="users" fill="#3B82F6" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {/* Popular Coins */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Popular Coins
          </h3>
          <div className="space-y-4">
            {popularCoins.map((coin, index) => (
              <div key={coin} className="flex items-center justify-between">
                <span className="text-gray-600 dark:text-gray-400">{coin}</span>
                <span className="text-gray-900 dark:text-white font-medium">
                  #{index + 1}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Popular Countries */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Top Countries
          </h3>
          <div className="space-y-4">
            {popularCountries.map((country, index) => (
              <div key={country} className="flex items-center justify-between">
                <span className="text-gray-600 dark:text-gray-400">{country}</span>
                <span className="text-gray-900 dark:text-white font-medium">
                  #{index + 1}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* System Health */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            System Health
          </h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Clock className="h-5 w-5 text-green-500 mr-2" />
                <span className="text-gray-600 dark:text-gray-400">Uptime</span>
              </div>
              <span className="text-gray-900 dark:text-white font-medium">
                99.9%
              </span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Activity className="h-5 w-5 text-blue-500 mr-2" />
                <span className="text-gray-600 dark:text-gray-400">Response Time</span>
              </div>
              <span className="text-gray-900 dark:text-white font-medium">
                250ms
              </span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <AlertTriangle className="h-5 w-5 text-yellow-500 mr-2" />
                <span className="text-gray-600 dark:text-gray-400">Error Rate</span>
              </div>
              <span className="text-gray-900 dark:text-white font-medium">
                0.1%
              </span>
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default Dashboard;