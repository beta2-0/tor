import React, { useState } from 'react';
import { Save } from 'lucide-react';
import AdminLayout from '../../components/layout/AdminLayout';
import Input from '../../components/ui/Input';
import Button from '../../components/ui/Button';

const Settings: React.FC = () => {
  const [settings, setSettings] = useState({
    platformFee: '1.5',
    minTransactionAmount: '100',
    maxTransactionAmount: '10000',
    supportEmail: 'support@cryptosell.com',
    supportPhone: '+1234567890'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, save to Supabase
    alert('Settings saved successfully!');
  };

  return (
    <AdminLayout>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Platform Settings</h1>
        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
          Configure global platform settings and parameters
        </p>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md">
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
                Transaction Settings
              </h3>
              
              <div className="space-y-4">
                <Input
                  label="Platform Fee (%)"
                  type="number"
                  step="0.1"
                  value={settings.platformFee}
                  onChange={(e) => setSettings({ ...settings, platformFee: e.target.value })}
                  fullWidth
                />
                
                <Input
                  label="Minimum Transaction Amount"
                  type="number"
                  value={settings.minTransactionAmount}
                  onChange={(e) => setSettings({ ...settings, minTransactionAmount: e.target.value })}
                  fullWidth
                />
                
                <Input
                  label="Maximum Transaction Amount"
                  type="number"
                  value={settings.maxTransactionAmount}
                  onChange={(e) => setSettings({ ...settings, maxTransactionAmount: e.target.value })}
                  fullWidth
                />
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
                Support Information
              </h3>
              
              <div className="space-y-4">
                <Input
                  label="Support Email"
                  type="email"
                  value={settings.supportEmail}
                  onChange={(e) => setSettings({ ...settings, supportEmail: e.target.value })}
                  fullWidth
                />
                
                <Input
                  label="Support Phone"
                  type="tel"
                  value={settings.supportPhone}
                  onChange={(e) => setSettings({ ...settings, supportPhone: e.target.value })}
                  fullWidth
                />
              </div>
            </div>
          </div>
          
          <div className="flex justify-end pt-6 border-t border-gray-200 dark:border-gray-700">
            <Button
              type="submit"
              variant="primary"
            >
              <Save className="h-4 w-4 mr-2" />
              Save Settings
            </Button>
          </div>
        </form>
      </div>
    </AdminLayout>
  );
};

export default Settings;