import React, { useEffect, useState } from 'react';
import {
  createColumnHelper,
  flexRender,
  getCoreRowModel,
  useReactTable,
  getSortedRowModel,
  SortingState,
  getPaginationRowModel,
  ColumnDef
} from '@tanstack/react-table';
import { ChevronDown, ChevronUp, Search, Filter } from 'lucide-react';
import AdminLayout from '../../components/layout/AdminLayout';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Select from '../../components/ui/Select';
import { useAdminStore } from '../../store/adminStore';
import { Offer, CryptoCoin, Country } from '../../types';
import { COINS, COUNTRIES } from '../../constants';

const columnHelper = createColumnHelper<Offer>();

const Offers: React.FC = () => {
  const { offers, fetchOffers, updateOfferStatus } = useAdminStore();
  const [sorting, setSorting] = useState<SortingState>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCoin, setSelectedCoin] = useState<string>('all');
  const [selectedCountry, setSelectedCountry] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [filteredOffers, setFilteredOffers] = useState<Offer[]>([]);

  useEffect(() => {
    fetchOffers();
  }, [fetchOffers]);

  useEffect(() => {
    let filtered = [...offers];

    // Apply search filter
    if (searchTerm) {
      filtered = filtered.filter(offer => 
        offer.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        offer.userId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        offer.walletAddress.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Apply coin filter
    if (selectedCoin !== 'all') {
      filtered = filtered.filter(offer => offer.coin === selectedCoin);
    }

    // Apply country filter
    if (selectedCountry !== 'all') {
      filtered = filtered.filter(offer => offer.country === selectedCountry);
    }

    // Apply status filter
    if (selectedStatus !== 'all') {
      filtered = filtered.filter(offer => offer.status === selectedStatus);
    }

    setFilteredOffers(filtered);
  }, [offers, searchTerm, selectedCoin, selectedCountry, selectedStatus]);

  const columns = [
    columnHelper.accessor('id', {
      header: 'Order ID',
      cell: info => info.getValue(),
    }),
    columnHelper.accessor('coin', {
      header: 'Coin',
      cell: info => info.getValue(),
    }),
    columnHelper.accessor('country', {
      header: 'Country',
      cell: info => info.getValue(),
    }),
    columnHelper.accessor('price', {
      header: 'Price',
      cell: info => (
        <span>
          {info.getValue().toLocaleString()} {
            info.row.original.country === 'India' ? 'INR' :
            info.row.original.country === 'USA' ? 'USD' : 'NGN'
          }
        </span>
      ),
    }),
    columnHelper.accessor('amount', {
      header: 'Amount',
      cell: info => (
        <span>
          {info.getValue().toLocaleString()} {info.row.original.coin}
        </span>
      ),
    }),
    columnHelper.accessor('paymentMethod', {
      header: 'Payment',
      cell: info => info.getValue().replace(/_/g, ' '),
    }),
    columnHelper.accessor('status', {
      header: 'Status',
      cell: info => (
        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
          ${info.getValue() === 'active' 
            ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
            : info.getValue() === 'completed'
            ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
            : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
          }`}
        >
          {info.getValue()}
        </span>
      ),
    }),
    columnHelper.accessor('createdAt', {
      header: 'Created',
      cell: info => new Date(info.getValue()).toLocaleDateString(),
    }),
    columnHelper.display({
      id: 'actions',
      cell: info => (
        <div className="flex justify-end space-x-2">
          {info.row.original.status === 'active' && (
            <>
              <Button
                variant="primary"
                size="sm"
                onClick={() => updateOfferStatus(info.row.original.id, 'completed')}
              >
                Complete
              </Button>
              <Button
                variant="danger"
                size="sm"
                onClick={() => updateOfferStatus(info.row.original.id, 'cancelled')}
              >
                Cancel
              </Button>
            </>
          )}
        </div>
      ),
    }),
  ];

  const table = useReactTable({
    data: filteredOffers,
    columns,
    state: {
      sorting,
    },
    onSortingChange: setSorting,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
  });

  return (
    <AdminLayout>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Offers</h1>
        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
          Manage and monitor all platform offers
        </p>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md">
        {/* Filters */}
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <div className="relative">
              <Input
                placeholder="Search by ID, User, or Wallet"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
                fullWidth
              />
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
            </div>
            
            <Select
              options={[
                { value: 'all', label: 'All Coins' },
                ...COINS.map(coin => ({ value: coin, label: coin }))
              ]}
              value={selectedCoin}
              onChange={setSelectedCoin}
              fullWidth
            />
            
            <Select
              options={[
                { value: 'all', label: 'All Countries' },
                ...COUNTRIES.map(country => ({ value: country, label: country }))
              ]}
              value={selectedCountry}
              onChange={setSelectedCountry}
              fullWidth
            />
            
            <Select
              options={[
                { value: 'all', label: 'All Status' },
                { value: 'active', label: 'Active' },
                { value: 'completed', label: 'Completed' },
                { value: 'cancelled', label: 'Cancelled' }
              ]}
              value={selectedStatus}
              onChange={setSelectedStatus}
              fullWidth
            />
            
            <Button
              variant="outline"
              onClick={() => {
                setSearchTerm('');
                setSelectedCoin('all');
                setSelectedCountry('all');
                setSelectedStatus('all');
              }}
              fullWidth
            >
              <Filter className="h-4 w-4 mr-2" />
              Reset Filters
            </Button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-900">
              {table.getHeaderGroups().map(headerGroup => (
                <tr key={headerGroup.id}>
                  {headerGroup.headers.map(header => (
                    <th
                      key={header.id}
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider"
                    >
                      {header.isPlaceholder ? null : (
                        <div
                          className={`flex items-center space-x-1 ${
                            header.column.getCanSort() ? 'cursor-pointer select-none' : ''
                          }`}
                          onClick={header.column.getToggleSortingHandler()}
                        >
                          <span>{flexRender(
                            header.column.columnDef.header,
                            header.getContext()
                          )}</span>
                          {{
                            asc: <ChevronUp className="h-4 w-4" />,
                            desc: <ChevronDown className="h-4 w-4" />
                          }[header.column.getIsSorted() as string] ?? null}
                        </div>
                      )}
                    </th>
                  ))}
                </tr>
              ))}
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {table.getRowModel().rows.map(row => (
                <tr key={row.id}>
                  {row.getVisibleCells().map(cell => (
                    <td
                      key={cell.id}
                      className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white"
                    >
                      {flexRender(
                        cell.column.columnDef.cell,
                        cell.getContext()
                      )}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        <div className="px-6 py-4 flex items-center justify-between border-t border-gray-200 dark:border-gray-700">
          <div className="flex-1 flex justify-between sm:hidden">
            <Button
              variant="outline"
              onClick={() => table.previousPage()}
              disabled={!table.getCanPreviousPage()}
            >
              Previous
            </Button>
            <Button
              variant="outline"
              onClick={() => table.nextPage()}
              disabled={!table.getCanNextPage()}
            >
              Next
            </Button>
          </div>
          <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
            <div className="flex gap-x-2">
              <span className="text-sm text-gray-700 dark:text-gray-400">
                Page <span className="font-medium">{table.getState().pagination.pageIndex + 1}</span>{' '}
                of <span className="font-medium">{table.getPageCount()}</span>
              </span>
            </div>
            <div className="flex gap-x-2">
              <Button
                variant="outline"
                onClick={() => table.previousPage()}
                disabled={!table.getCanPreviousPage()}
              >
                Previous
              </Button>
              <Button
                variant="outline"
                onClick={() => table.nextPage()}
                disabled={!table.getCanNextPage()}
              >
                Next
              </Button>
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default Offers;