import React, { useEffect, useState } from 'react';
import { Send } from 'lucide-react';
import AdminLayout from '../../components/layout/AdminLayout';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../../components/ui/Tabs';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import { useOfferStore } from '../../store/offerStore';
import { useMessageStore } from '../../store/messageStore';

const Orders: React.FC = () => {
  const { offers, fetchOffers, updateOfferStatus } = useOfferStore();
  const { messages, fetchMessages, sendMessage } = useMessageStore();
  const [selectedOfferId, setSelectedOfferId] = useState<string | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const [statusMessage, setStatusMessage] = useState('');
  const [showStatusInput, setShowStatusInput] = useState<'completed' | 'cancelled' | null>(null);
  const [activeTab, setActiveTab] = useState('all');
  const [isUpdating, setIsUpdating] = useState(false);

  useEffect(() => {
    fetchOffers(true);
  }, [fetchOffers]);

  useEffect(() => {
    if (selectedOfferId) {
      fetchMessages(selectedOfferId);
    }
  }, [selectedOfferId, fetchMessages]);

  const handleSendMessage = async () => {
    if (!selectedOfferId || !newMessage.trim()) return;

    const { success } = await sendMessage(selectedOfferId, newMessage, true);
    if (success) {
      setNewMessage('');
      fetchMessages(selectedOfferId);
    }
  };

  const handleStatusUpdate = async (offerId: string, status: 'completed' | 'cancelled') => {
    if (!statusMessage.trim()) {
      setShowStatusInput(status);
      return;
    }

    setIsUpdating(true);
    try {
      const { success } = await updateOfferStatus(offerId, status);
      if (success) {
        await sendMessage(offerId, statusMessage, true);
        setStatusMessage('');
        setShowStatusInput(null);
        fetchMessages(offerId);
        fetchOffers(true);
        // Clear selected order if it was just completed/cancelled
        if (activeTab === 'active') {
          setSelectedOfferId(null);
        }
      }
    } finally {
      setIsUpdating(false);
    }
  };

  // Filter offers based on active tab
  const filteredOffers = offers.filter(offer => {
    if (activeTab === 'all') return true;
    return offer.status === 'active';
  }).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const selectedOffer = selectedOfferId ? offers.find(o => o.id === selectedOfferId) : null;

  return (
    <AdminLayout>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Orders</h1>
        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
          Manage sell orders and communicate with users
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Orders List */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <Tabs defaultValue="all" className="w-full" onValueChange={setActiveTab}>
            <TabsList>
              <TabsTrigger value="all">📋 All Orders</TabsTrigger>
              <TabsTrigger value="active">🟢 Active Orders</TabsTrigger>
            </TabsList>

            <TabsContent value={activeTab} className="mt-4">
              <div className="space-y-4">
                {filteredOffers.length === 0 ? (
                  <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                    No {activeTab !== 'all' ? activeTab : ''} orders found
                  </div>
                ) : (
                  filteredOffers.map(offer => (
                    <button
                      key={offer.id}
                      onClick={() => setSelectedOfferId(offer.id)}
                      className={`
                        w-full text-left p-4 rounded-lg border transition-colors
                        ${selectedOfferId === offer.id
                          ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                          : 'border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700'
                        }
                      `}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-mono text-sm text-gray-600 dark:text-gray-400">
                            {offer.id}
                          </p>
                          <p className="mt-1 font-medium text-gray-900 dark:text-white">
                            {offer.amount} {offer.coin}
                          </p>
                          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                            {new Date(offer.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <span className={`
                          inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                          ${offer.status === 'active'
                            ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                            : offer.status === 'completed'
                            ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
                            : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                          }
                        `}>
                          {offer.status}
                        </span>
                      </div>
                    </button>
                  ))
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Messages Panel */}
        <div className="lg:col-span-2 bg-white dark:bg-gray-800 rounded-lg shadow-md">
          {selectedOfferId && selectedOffer ? (
            <div className="h-full flex flex-col">
              <div className="p-6 border-b border-gray-200 dark:border-gray-700">
                <div className="flex justify-between items-center">
                  <div>
                    <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                      Order Details
                    </h2>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Order ID: {selectedOfferId}
                    </p>
                  </div>
                  
                  {selectedOffer.status === 'active' && (
                    <div className="flex space-x-2">
                      <Button
                        variant="primary"
                        size="sm"
                        onClick={() => handleStatusUpdate(selectedOfferId, 'completed')}
                        isLoading={isUpdating}
                      >
                        Complete Order
                      </Button>
                      <Button
                        variant="danger"
                        size="sm"
                        onClick={() => handleStatusUpdate(selectedOfferId, 'cancelled')}
                        isLoading={isUpdating}
                      >
                        Reject Order
                      </Button>
                    </div>
                  )}
                </div>

                {showStatusInput && (
                  <div className="mt-4 flex space-x-2">
                    <Input
                      value={statusMessage}
                      onChange={(e) => setStatusMessage(e.target.value)}
                      placeholder={`Enter description for ${showStatusInput} status...`}
                      fullWidth
                    />
                    <Button
                      variant={showStatusInput === 'completed' ? 'primary' : 'danger'}
                      onClick={() => handleStatusUpdate(selectedOfferId, showStatusInput)}
                      disabled={!statusMessage.trim()}
                      isLoading={isUpdating}
                    >
                      Confirm
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => {
                        setShowStatusInput(null);
                        setStatusMessage('');
                      }}
                    >
                      Cancel
                    </Button>
                  </div>
                )}

                <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-500 dark:text-gray-400">Amount:</span>
                    <span className="ml-2 font-medium text-gray-900 dark:text-white">
                      {selectedOffer.amount} {selectedOffer.coin}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-500 dark:text-gray-400">Price:</span>
                    <span className="ml-2 font-medium text-gray-900 dark:text-white">
                      {selectedOffer.price.toLocaleString()} {
                        selectedOffer.country === 'India' ? 'INR' :
                        selectedOffer.country === 'USA' ? 'USD' : 'NGN'
                      }
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-500 dark:text-gray-400">Payment:</span>
                    <span className="ml-2 font-medium text-gray-900 dark:text-white">
                      {selectedOffer.paymentMethod.replace(/_/g, ' ')}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-500 dark:text-gray-400">Country:</span>
                    <span className="ml-2 font-medium text-gray-900 dark:text-white">
                      {selectedOffer.country}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex-1 p-6 overflow-y-auto">
                <div className="space-y-4">
                  {messages[selectedOfferId]?.length > 0 ? (
                    messages[selectedOfferId].map(message => (
                      <div
                        key={message.id}
                        className={`flex ${message.isAdmin ? 'justify-end' : 'justify-start'}`}
                      >
                        <div className={`
                          max-w-[80%] rounded-lg px-4 py-2
                          ${message.isAdmin
                            ? 'bg-blue-500 text-white'
                            : 'bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white'
                          }
                        `}>
                          <p className="text-sm">{message.content}</p>
                          <p className="text-xs mt-1 opacity-70">
                            {new Date(message.createdAt).toLocaleTimeString()}
                          </p>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center text-gray-500 dark:text-gray-400">
                      No messages yet
                    </div>
                  )}
                </div>
              </div>

              <div className="p-4 border-t border-gray-200 dark:border-gray-700">
                <div className="flex space-x-2">
                  <Input
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder="Type your message..."
                    fullWidth
                  />
                  <Button
                    variant="primary"
                    onClick={handleSendMessage}
                    disabled={!newMessage.trim()}
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            <div className="h-[600px] flex items-center justify-center p-6 text-center">
              <div className="text-gray-500 dark:text-gray-400">
                <p className="text-lg font-medium mb-2">No order selected</p>
                <p className="text-sm">Select an order from the list to view details and messages</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </AdminLayout>
  );
};

export default Orders;