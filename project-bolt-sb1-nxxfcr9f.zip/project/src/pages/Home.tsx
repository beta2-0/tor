import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Zap, Shield, Globe } from 'lucide-react';
import Layout from '../components/layout/Layout';
import Button from '../components/ui/Button';
import { useOfferStore } from '../store/offerStore';
import OfferList from '../components/offer/OfferList';

const Home: React.FC = () => {
  const { offers, fetchOffers } = useOfferStore();
  
  useEffect(() => {
    fetchOffers();
  }, [fetchOffers]);
  
  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div className="text-center md:text-left">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Sell Your Crypto <span className="text-yellow-300">Safely</span>
              </h1>
              <p className="text-xl mb-8">
                The most trusted P2P platform for selling cryptocurrency across multiple countries.
              </p>
              <div className="flex flex-col sm:flex-row justify-center md:justify-start space-y-4 sm:space-y-0 sm:space-x-4">
                <Link to="/register">
                  <Button 
                    variant="secondary" 
                    size="lg" 
                    className="font-semibold transition-transform hover:scale-105"
                  >
                    Get Started
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Link to="/dashboard">
                  <Button 
                    variant="outline" 
                    size="lg" 
                    className="border-white text-white hover:bg-white hover:bg-opacity-10 font-semibold"
                  >
                    View Offers
                  </Button>
                </Link>
              </div>
            </div>
            <div className="hidden md:block">
              <img 
                src="https://images.pexels.com/photos/6780789/pexels-photo-6780789.jpeg?auto=compress&cs=tinysrgb&w=600" 
                alt="Cryptocurrency Trading" 
                className="rounded-lg shadow-2xl max-h-96 object-cover"
              />
            </div>
          </div>
        </div>
        
        {/* Wave divider */}
        <div className="absolute bottom-0 left-0 right-0">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 100" className="fill-current text-gray-100 dark:text-gray-900">
            <path d="M0,64L80,58.7C160,53,320,43,480,48C640,53,800,75,960,74.7C1120,75,1280,53,1360,42.7L1440,32L1440,100L1360,100C1280,100,1120,100,960,100C800,100,640,100,480,100C320,100,160,100,80,100L0,100Z"></path>
          </svg>
        </div>
      </section>
      
      {/* Features Section */}
      <section className="py-20 bg-gray-100 dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-800 dark:text-white">Why Choose CryptoSell?</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow-md transition-transform hover:scale-105">
              <div className="bg-blue-100 dark:bg-blue-900 p-3 rounded-full w-12 h-12 flex items-center justify-center mb-4">
                <Shield className="h-6 w-6 text-blue-600 dark:text-blue-300" />
              </div>
              <h3 className="text-xl font-bold mb-2 text-gray-800 dark:text-white">Secure Transactions</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Every transaction is verified and our escrow service ensures your funds are protected.
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow-md transition-transform hover:scale-105">
              <div className="bg-purple-100 dark:bg-purple-900 p-3 rounded-full w-12 h-12 flex items-center justify-center mb-4">
                <Zap className="h-6 w-6 text-purple-600 dark:text-purple-300" />
              </div>
              <h3 className="text-xl font-bold mb-2 text-gray-800 dark:text-white">Fast & Simple</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Create a sell offer in minutes and receive payment quickly through various payment methods.
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow-md transition-transform hover:scale-105">
              <div className="bg-green-100 dark:bg-green-900 p-3 rounded-full w-12 h-12 flex items-center justify-center mb-4">
                <Globe className="h-6 w-6 text-green-600 dark:text-green-300" />
              </div>
              <h3 className="text-xl font-bold mb-2 text-gray-800 dark:text-white">Global Coverage</h3>
              <p className="text-gray-600 dark:text-gray-400">
                We support multiple countries and payment methods for maximum flexibility.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Recent Offers Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 dark:text-white mb-4">Recent Offers</h2>
            <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              Browse the latest sell offers from our users. Create an account to contact sellers.
            </p>
          </div>
          
          {/* Display recent offers */}
          <OfferList offers={offers.slice(0, 3)} />
          
          <div className="text-center mt-10">
            <Link to="/dashboard">
              <Button variant="secondary">
                View All Offers
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="bg-gradient-to-r from-blue-600 to-purple-600 py-16 text-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Sell Your Crypto?</h2>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            Join thousands of users who safely sell their cryptocurrency through our platform.
          </p>
          <Link to="/register">
            <Button 
              variant="primary" 
              size="lg" 
              className="bg-white text-blue-600 hover:bg-gray-100"
            >
              Register Now
            </Button>
          </Link>
        </div>
      </section>
    </Layout>
  );
};

export default Home;