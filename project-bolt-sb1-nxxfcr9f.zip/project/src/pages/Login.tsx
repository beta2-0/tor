import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import Layout from '../components/layout/Layout';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';
import { useAuthStore } from '../store/authStore';

interface LoginProps {
  isAdminLogin?: boolean;
}

const Login: React.FC<LoginProps> = ({ isAdminLogin = false }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { login, isAuthenticated, isAdmin } = useAuthStore();
  
  const [mobile, setMobile] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  // Redirect if already authenticated
  React.useEffect(() => {
    if (isAuthenticated) {
      if (isAdminLogin) {
        if (isAdmin()) {
          navigate('/admin');
        } else {
          setError('You do not have admin privileges');
        }
      } else {
        navigate('/dashboard');
      }
    }
  }, [isAuthenticated, navigate, isAdminLogin, isAdmin]);
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!mobile || !password) {
      setError('Please enter both username and password');
      return;
    }
    
    setIsLoading(true);
    setError('');
    
    try {
      const { success, error } = await login(mobile, password);
      
      if (success) {
        if (isAdminLogin) {
          if (isAdmin()) {
            navigate('/admin');
          } else {
            setError('You do not have admin privileges');
          }
        } else {
          navigate('/dashboard');
        }
      } else {
        setError(error || 'Invalid credentials');
      }
    } catch (err) {
      setError('An unexpected error occurred');
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <Layout>
      <div className="min-h-[calc(100vh-64px-200px)] bg-gray-100 dark:bg-gray-900 py-16">
        <div className="max-w-md mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg overflow-hidden">
            <div className="px-6 py-8">
              <h2 className="text-2xl font-bold text-center text-gray-800 dark:text-white mb-8">
                {isAdminLogin ? 'Admin Login' : 'Log in to your account'}
              </h2>
              
              {error && (
                <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-md">
                  {error}
                </div>
              )}
              
              <form onSubmit={handleSubmit}>
                <Input
                  label={isAdminLogin ? 'Username' : 'Mobile Number'}
                  type={isAdminLogin ? 'text' : 'tel'}
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  placeholder={isAdminLogin ? 'Enter admin username' : 'Your mobile number'}
                  fullWidth
                />
                
                <Input
                  label="Password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={isAdminLogin ? 'Enter admin password' : 'Your password'}
                  fullWidth
                />
                
                {!isAdminLogin && (
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center">
                      <input
                        id="remember-me"
                        name="remember-me"
                        type="checkbox"
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      />
                      <label htmlFor="remember-me" className="ml-2 block text-sm text-gray-700 dark:text-gray-300">
                        Remember me
                      </label>
                    </div>
                    
                    <div className="text-sm">
                      <a href="#" className="text-blue-600 hover:text-blue-500 dark:text-blue-400">
                        Forgot password?
                      </a>
                    </div>
                  </div>
                )}
                
                <Button
                  type="submit"
                  variant="primary"
                  fullWidth
                  isLoading={isLoading}
                  className="mt-6"
                >
                  {isAdminLogin ? 'Login as Admin' : 'Log in'}
                </Button>
              </form>
            </div>
            
            {!isAdminLogin && (
              <div className="px-6 py-4 bg-gray-50 dark:bg-gray-700 border-t border-gray-200 dark:border-gray-600">
                <div className="text-center text-sm text-gray-600 dark:text-gray-400">
                  Don't have an account?{' '}
                  <Link to="/register" className="text-blue-600 hover:text-blue-500 dark:text-blue-400">
                    Register
                  </Link>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Login;