export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      offers: {
        Row: {
          id: string
          user_id: string
          coin: string
          country: string
          price: number
          payment_method: string
          wallet_address: string
          amount: number
          type: string
          created_at: string
          status: string
        }
        Insert: {
          id?: string
          user_id: string
          coin: string
          country: string
          price: number
          payment_method: string
          wallet_address: string
          amount: number
          type: string
          created_at?: string
          status?: string
        }
        Update: {
          id?: string
          user_id?: string
          coin?: string
          country?: string
          price?: number
          payment_method?: string
          wallet_address?: string
          amount?: number
          type?: string
          created_at?: string
          status?: string
        }
      }
      profiles: {
        Row: {
          id: string
          mobile: string
          wallets: Json
          created_at: string
        }
        Insert: {
          id: string
          mobile: string
          wallets?: Json
          created_at?: string
        }
        Update: {
          id?: string
          mobile?: string
          wallets?: Json
          created_at?: string
        }
      }
    }
  }
}