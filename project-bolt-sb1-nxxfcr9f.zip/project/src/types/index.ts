export enum CryptoCoin {
  BTC = 'BTC',
  ETH = 'ETH',
  USDT = 'USDT',
  BNB = 'BNB',
  USDC = 'USDC'
}

export enum Country {
  INDIA = 'India',
  USA = 'USA',
  NIGERIA = 'Nigeria'
}

export enum UserRole {
  USER = 'user',
  ADMIN = 'admin'
}

export enum DealStatus {
  PENDING = 'pending',
  PAID = 'paid',
  COMPLETED = 'completed'
}

export interface Message {
  id: string;
  offerId: string;
  content: string;
  createdAt: string;
  isAdmin: boolean;
}

export interface PaymentMethod {
  id: string;
  name: string;
  icon: string;
  countries: Country[];
}

export interface Offer {
  id: string;
  userId: string;
  coin: CryptoCoin;
  country: Country;
  price: number;
  amount: number;
  paymentMethod: string;
  walletAddress: string;
  type: 'sell';
  status: 'active' | 'completed' | 'cancelled';
  createdAt: string;
  messages?: Message[];
}

export interface Deal {
  id: string;
  offerId: string;
  buyerId: string;
  sellerId: string;
  status: DealStatus;
  createdAt: string;
  updatedAt: string;
  offer?: Offer;
}

export interface User {
  id: string;
  mobile: string;
  wallets: Record<CryptoCoin, string[]>;
  role: UserRole;
  status: 'active' | 'suspended';
  createdAt: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

export interface AdminStats {
  totalUsers: number;
  activeUsers: number;
  totalOffers: number;
  activeOffers: number;
  totalVolume: number;
  recentTransactions: {
    date: string;
    volume: number;
  }[];
  userGrowth: {
    daily: number;
    weekly: number;
    monthly: number;
  };
  offerMetrics: {
    completionRate: number;
    averageAmount: number;
    popularCoins: string[];
    popularCountries: string[];
  };
  systemHealth: {
    uptime: number;
    responseTime: number;
    errorRate: number;
  };
}